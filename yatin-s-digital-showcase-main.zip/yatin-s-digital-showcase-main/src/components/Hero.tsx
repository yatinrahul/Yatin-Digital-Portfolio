import { motion } from "framer-motion";
import { FaGithub, FaLinkedin, FaEnvelope, FaPhone, FaMapMarkerAlt } from "react-icons/fa";
import { Button } from "@/components/ui/button";

const Hero = () => {
  return (
    <section className="min-h-screen flex items-center justify-center relative overflow-hidden px-4 py-20">
      {/* Animated background elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <motion.div
          className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/10 rounded-full blur-3xl"
          animate={{
            scale: [1, 1.2, 1],
            opacity: [0.3, 0.5, 0.3],
          }}
          transition={{ duration: 8, repeat: Infinity }}
        />
        <motion.div
          className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-accent/10 rounded-full blur-3xl"
          animate={{
            scale: [1.2, 1, 1.2],
            opacity: [0.5, 0.3, 0.5],
          }}
          transition={{ duration: 8, repeat: Infinity, delay: 1 }}
        />
      </div>

      <div className="max-w-6xl mx-auto text-center relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          <motion.h1 
            className="text-5xl md:text-7xl font-bold mb-4 bg-gradient-primary bg-clip-text text-transparent"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
          >
            APPALA YATIN RAHUL
          </motion.h1>
          
          <motion.p 
            className="text-xl md:text-2xl text-muted-foreground mb-8"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
          >
            Software Engineering Intern | Full-Stack Developer | AI & ML Enthusiast
          </motion.p>

          <motion.div 
            className="flex flex-wrap items-center justify-center gap-4 md:gap-6 mb-10 text-sm md:text-base text-muted-foreground"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.6 }}
          >
            <div className="flex items-center gap-2">
              <FaMapMarkerAlt className="text-primary" />
              <span>Tenali, Guntur, India</span>
            </div>
            <div className="flex items-center gap-2">
              <FaPhone className="text-primary" />
              <span>+91 9381249414</span>
            </div>
            <div className="flex items-center gap-2">
              <FaEnvelope className="text-primary" />
              <a href="mailto:yatin.rahulappala@gmail.com" className="hover:text-primary transition-colors">
                yatin.rahulappala@gmail.com
              </a>
            </div>
          </motion.div>

          <motion.div 
            className="flex flex-wrap items-center justify-center gap-4"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.8 }}
          >
            <Button
              asChild
              size="lg"
              className="bg-gradient-primary text-primary-foreground hover:opacity-90 shadow-glow"
            >
              <a href="https://linkedin.com/in/appala-yatin-rahul" target="_blank" rel="noopener noreferrer">
                <FaLinkedin className="mr-2" />
                LinkedIn
              </a>
            </Button>
            <Button
              asChild
              size="lg"
              variant="secondary"
              className="hover:bg-secondary/80"
            >
              <a href="#" target="_blank" rel="noopener noreferrer">
                <FaGithub className="mr-2" />
                GitHub
              </a>
            </Button>
            <Button
              asChild
              size="lg"
              variant="outline"
              className="border-primary/50 hover:bg-primary/10"
            >
              <a href="#contact">
                <FaEnvelope className="mr-2" />
                Get in Touch
              </a>
            </Button>
          </motion.div>
        </motion.div>
      </div>
    </section>
  );
};

export default Hero;
