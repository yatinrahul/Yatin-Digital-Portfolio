import { motion } from "framer-motion";
import { useInView } from "framer-motion";
import { useRef } from "react";
import { FaGithub, FaLinkedin, FaEnvelope, FaPhone, FaMapMarkerAlt } from "react-icons/fa";
import { Button } from "@/components/ui/button";

const Contact = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section id="contact" className="py-20 px-4">
      <div className="max-w-4xl mx-auto">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 50 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 50 }}
          transition={{ duration: 0.8 }}
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-12 text-center">
            <span className="bg-gradient-primary bg-clip-text text-transparent">Get In Touch</span>
          </h2>

          <div className="bg-card border border-border rounded-xl p-8 shadow-card-shadow">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
              <div className="flex items-center gap-4">
                <div className="p-3 bg-primary/10 rounded-lg">
                  <FaEnvelope className="text-xl text-primary" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Email</p>
                  <a href="mailto:yatin.rahulappala@gmail.com" className="text-foreground hover:text-primary transition-colors">
                    yatin.rahulappala@gmail.com
                  </a>
                </div>
              </div>

              <div className="flex items-center gap-4">
                <div className="p-3 bg-primary/10 rounded-lg">
                  <FaPhone className="text-xl text-primary" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Phone</p>
                  <a href="tel:+919381249414" className="text-foreground hover:text-primary transition-colors">
                    +91 9381249414
                  </a>
                </div>
              </div>

              <div className="flex items-center gap-4">
                <div className="p-3 bg-primary/10 rounded-lg">
                  <FaMapMarkerAlt className="text-xl text-primary" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">Location</p>
                  <p className="text-foreground">Tenali, Guntur, India</p>
                </div>
              </div>

              <div className="flex items-center gap-4">
                <div className="p-3 bg-primary/10 rounded-lg">
                  <FaLinkedin className="text-xl text-primary" />
                </div>
                <div>
                  <p className="text-sm text-muted-foreground">LinkedIn</p>
                  <a 
                    href="https://linkedin.com/in/appala-yatin-rahul" 
                    target="_blank" 
                    rel="noopener noreferrer"
                    className="text-foreground hover:text-primary transition-colors"
                  >
                    View Profile
                  </a>
                </div>
              </div>
            </div>

            <div className="flex flex-wrap justify-center gap-4 pt-6 border-t border-border">
              <Button
                asChild
                size="lg"
                className="bg-gradient-primary text-primary-foreground hover:opacity-90 shadow-glow"
              >
                <a href="mailto:yatin.rahulappala@gmail.com">
                  <FaEnvelope className="mr-2" />
                  Send Email
                </a>
              </Button>
              <Button
                asChild
                size="lg"
                variant="outline"
                className="border-primary/50 hover:bg-primary/10"
              >
                <a href="https://linkedin.com/in/appala-yatin-rahul" target="_blank" rel="noopener noreferrer">
                  <FaLinkedin className="mr-2" />
                  Connect on LinkedIn
                </a>
              </Button>
            </div>
          </div>

          <div className="mt-12 text-center">
            <p className="text-muted-foreground mb-4">
              💪 <strong>Strengths:</strong> Problem‑solving • Team Collaboration • Communication • Innovation‑Driven • Adaptable • Leadership
            </p>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default Contact;
