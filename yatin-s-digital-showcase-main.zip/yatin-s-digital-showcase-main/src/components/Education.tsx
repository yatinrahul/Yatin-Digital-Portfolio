import { motion } from "framer-motion";
import { useInView } from "framer-motion";
import { useRef } from "react";
import { FaGraduationCap } from "react-icons/fa";

const educationData = [
  {
    degree: "B.Tech – Artificial Intelligence & Data Science",
    institution: "KL University, Vijayawada",
    period: "2023 – Present",
    achievement: "CGPA: 9.1",
  },
  {
    degree: "Higher Secondary (Class 11–12)",
    institution: "Sri Chaitanya Junior College",
    period: "Completed",
    achievement: "86.5%",
  },
  {
    degree: "High School (Class X)",
    institution: "Bhashyam School",
    period: "Completed",
    achievement: "GPA: 10/10",
  },
];

const Education = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section id="education" className="py-20 px-4">
      <div className="max-w-4xl mx-auto">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 50 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 50 }}
          transition={{ duration: 0.8 }}
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-12 text-center">
            <span className="bg-gradient-primary bg-clip-text text-transparent">Education</span>
          </h2>

          <div className="space-y-6">
            {educationData.map((edu, index) => (
              <motion.div
                key={edu.degree}
                initial={{ opacity: 0, x: 50 }}
                animate={isInView ? { opacity: 1, x: 0 } : { opacity: 0, x: 50 }}
                transition={{ duration: 0.5, delay: index * 0.2 }}
                className="bg-card border border-border rounded-xl p-6 shadow-card-shadow hover:shadow-glow transition-shadow duration-300"
              >
                <div className="flex items-start gap-4">
                  <div className="p-3 bg-primary/10 rounded-lg">
                    <FaGraduationCap className="text-2xl text-primary" />
                  </div>
                  <div className="flex-1">
                    <div className="flex flex-col md:flex-row md:items-center md:justify-between mb-2">
                      <h3 className="text-xl font-bold">{edu.degree}</h3>
                      <span className="text-sm text-primary font-semibold mt-1 md:mt-0">{edu.achievement}</span>
                    </div>
                    <p className="text-muted-foreground mb-1">{edu.institution}</p>
                    <p className="text-sm text-muted-foreground">{edu.period}</p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default Education;
