import { motion } from "framer-motion";
import { useInView } from "framer-motion";
import { useRef } from "react";

const About = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section id="about" className="py-20 px-4">
      <div className="max-w-4xl mx-auto">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 50 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 50 }}
          transition={{ duration: 0.8 }}
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-8 text-center">
            <span className="bg-gradient-primary bg-clip-text text-transparent">About Me</span>
          </h2>
          
          <div className="bg-card border border-border rounded-xl p-8 shadow-card-shadow">
            <p className="text-lg text-muted-foreground leading-relaxed">
              Highly motivated Software Engineering student with strong skills in web development, UI
              engineering, and machine learning. Experienced in building scalable, user‑focused applications using React,
              JavaScript, Node.js, and Python. Strong foundation in OOP, data structures, and CNN-based image
              classification. Passionate about secure digital payment systems, performance optimization, and solving
              real‑world engineering challenges. Seeking to contribute to innovative projects that enable safe, reliable, and
              inclusive digital solutions globally.
            </p>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default About;
