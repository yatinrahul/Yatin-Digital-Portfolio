import { motion } from "framer-motion";
import { useInView } from "framer-motion";
import { useRef } from "react";
import { FaCode, FaExternalLinkAlt } from "react-icons/fa";

const projectsData = [
  {
    title: "Ride Sharing Website",
    subtitle: "Full Stack (React + Node.js)",
    period: "Dec 2024 – Mar 2025",
    description: [
      "Developed a responsive ride-booking portal with live ride matching & location‑based search",
      "Integrated secure digital payment workflow for smooth fare transfer between rider & driver",
      "Reduced page load time by optimizing bundle size & image compression",
      "Improved user experience with reusable UI components and error‑handled request flow",
    ],
    icon: "🚕",
  },
  {
    title: "Guava Disease Detection using CNN",
    subtitle: "Machine Learning Project",
    period: "Feb 2025",
    description: [
      "Trained a Convolutional Neural Network model for disease prediction from leaf images",
      "Designed prototype UI in Figma and implemented real-time inference pipeline",
      "Built reusable UI templates to accelerate design iteration & improve usability",
    ],
    icon: "🥝",
  },
  {
    title: "Pedestrian Identification System",
    subtitle: "YOLO and OpenCV",
    period: "2024",
    description: [
      "Developed a real-time pedestrian identification system using YOLO and OpenCV",
      "Optimized detection for high accuracy and speed across varying conditions",
      "Handled different lighting, weather, and crowded scenarios effectively",
    ],
    icon: "🚶",
  },
];

const Projects = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section id="projects" className="py-20 px-4">
      <div className="max-w-6xl mx-auto">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 50 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 50 }}
          transition={{ duration: 0.8 }}
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-12 text-center">
            <span className="bg-gradient-primary bg-clip-text text-transparent">Featured Projects</span>
          </h2>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {projectsData.map((project, index) => (
              <motion.div
                key={project.title}
                initial={{ opacity: 0, y: 20 }}
                animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 20 }}
                transition={{ duration: 0.5, delay: index * 0.2 }}
                className="bg-card border border-border rounded-xl p-8 shadow-card-shadow hover:shadow-glow transition-all duration-300 group"
              >
                <div className="flex items-start gap-4 mb-4">
                  <span className="text-4xl">{project.icon}</span>
                  <div className="flex-1">
                    <h3 className="text-2xl font-bold mb-1 group-hover:text-primary transition-colors">
                      {project.title}
                    </h3>
                    <p className="text-sm text-muted-foreground mb-1">{project.subtitle}</p>
                    <p className="text-xs text-primary">{project.period}</p>
                  </div>
                </div>

                <ul className="space-y-2">
                  {project.description.map((item, i) => (
                    <li key={i} className="text-muted-foreground flex items-start gap-2">
                      <span className="text-primary mt-1">•</span>
                      <span>{item}</span>
                    </li>
                  ))}
                </ul>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default Projects;
