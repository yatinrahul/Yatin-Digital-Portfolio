import { motion } from "framer-motion";
import { useInView } from "framer-motion";
import { useRef } from "react";
import { FaCertificate } from "react-icons/fa";

const certificationsData = [
  "Google Android Developer Virtual Internship – AICTE",
  "SQL Advanced – HackerRank",
  "IBM – Developing Frontend Apps with React",
  "MongoDB Associate Developer",
  "Oracle Certified DevOps Professional",
  "Aviatrix ACE Multicloud Network Associate",
  "Scrum Fundamentals Certified",
];

const Certifications = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  return (
    <section id="certifications" className="py-20 px-4 bg-secondary/30">
      <div className="max-w-6xl mx-auto">
        <motion.div
          ref={ref}
          initial={{ opacity: 0, y: 50 }}
          animate={isInView ? { opacity: 1, y: 0 } : { opacity: 0, y: 50 }}
          transition={{ duration: 0.8 }}
        >
          <h2 className="text-4xl md:text-5xl font-bold mb-12 text-center">
            <span className="bg-gradient-primary bg-clip-text text-transparent">Certifications</span>
          </h2>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {certificationsData.map((cert, index) => (
              <motion.div
                key={cert}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={isInView ? { opacity: 1, scale: 1 } : { opacity: 0, scale: 0.9 }}
                transition={{ duration: 0.4, delay: index * 0.1 }}
                className="bg-card border border-border rounded-xl p-6 shadow-card-shadow hover:shadow-glow transition-all duration-300 hover:scale-105"
              >
                <div className="flex items-start gap-3">
                  <FaCertificate className="text-2xl text-primary flex-shrink-0 mt-1" />
                  <p className="text-foreground">{cert}</p>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default Certifications;
